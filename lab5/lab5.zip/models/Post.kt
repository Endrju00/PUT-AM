package com.example.jsonapp.models

class Post(val userId: Int, val id: Int, val title: String, val body: String) {
}