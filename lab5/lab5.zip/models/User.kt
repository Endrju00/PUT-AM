package com.example.jsonapp.models

class User(val id: Int, val name: String, val email: String, var todos: Int = 0, var posts: Int = 0) {

}