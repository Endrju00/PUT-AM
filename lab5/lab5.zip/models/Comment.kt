package com.example.jsonapp.models

class Comment(val postId: Int, val id: Int, val name: String, val email: String, val body: String) {
}