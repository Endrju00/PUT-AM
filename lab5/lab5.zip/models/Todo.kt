package com.example.jsonapp.models

class Todo(val userId: Int, val id: Int, val title: String, val completed: Boolean) {
}